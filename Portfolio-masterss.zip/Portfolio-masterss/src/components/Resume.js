import React, { Fragment } from 'react'
import {  SiHackerrank } from 'react-icons/si';

function Resume() {
  return (
    <Fragment>
        <div className="col p-4"> 
            <div className="p-4 bg-dark slide-in-top">
                
                <div className="row">
                    <div className="col-6">
                        <h2 className="ff-jose fw-bold ls-2">Shraddha</h2>
                    </div>
                </div>
                <hr></hr>
                <div className="row">
                    <div className="col-md-6">
                        <h4 className="ff-jose ls-2">EXPERIENCE</h4>
                        <ul>
                            <li>
                                <h4 className="ff-jose my-1 text-red">FullStack Developer</h4>
                                <h6 className="blue-label px-2 py-1">Sep 2022 - feb 2023</h6>
                                <p className="m-0">Times Pro Pvt. Ltd.</p>
                                
                            </li>
                            <li>
                                <h4 className="ff-jose my-1 text-red">MIS Executive</h4>
                                <h6 className="blue-label px-2 py-1">Sep 2022 - March 2023</h6>
                                <p className="m-0">BioBazaar · Internship</p>
                                <p>Indore, MP, India</p>
                            </li>
                        </ul>
                    </div>
                    <div className="col-md-6">
                        
                        <h4 className="ff-jose ls-2">EDUCATION</h4>
                        <ul>
                            <li>
                                <h4 className="ff-jose my-1 text-red">BE - Computer Science</h4>
                                <h6 className="blue-label px-2 py-1">2016 - 2019</h6>
                                <p className="m-0">MRSC Pro. Science Collage.</p>
                                <p>CGPA: 6.50</p>
                            </li>
                            <li>
                                <h4 className="ff-jose my-1 text-red">Master of computer Science</h4>
                                <h6 className="blue-label px-2 py-1">2019 - 2021</h6>
                                <p className="m-0">GNSPS Collage.</p>
                                <p>Grade: 80.2%</p>
                            </li>
                        </ul>

                    </div>
                </div>

                <hr></hr>
                
                <div className="row">
                    <div className="col-md-6">
                        <h4 className="ff-jose ls-2">PROFILE</h4>
                        <h1>
                            <a href="https://www.hackerrank.com/dashboard" target="/blank" className="text-white text-decoration-none mx-2">
                                <SiHackerrank className="zoom-on-hover"/>
                            </a> 
                        </h1>
                    </div>
                </div>
                
            </div>
        </div>
    </Fragment>
  )
}

export default Resume